from django.apps import AppConfig


class NavigConfig(AppConfig):
    name = 'navig'
